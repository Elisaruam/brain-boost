# brain_boost/__init__.py
from .memory_exercise import memory_exercise
from .mental_math import mental_math
from .general_knowledge import general_knowledge
